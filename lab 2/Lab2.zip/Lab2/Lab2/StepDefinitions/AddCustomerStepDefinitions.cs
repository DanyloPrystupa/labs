using Braintree;
using Lab2.Drivers;
using Lab2.PageObjects;
using Lab2.Models;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using TechTalk.SpecFlow.Assist;
using Microsoft.VisualStudio.TestPlatform.CommunicationUtilities;
using System.Runtime.Intrinsics.X86;

namespace Lab2.StepDefinitions
{
    [Binding]
    public sealed class AddCustomerStepDefinitions
    {
        private readonly AddCustomerPageObjects addCustomerPage;
        private readonly LogInBankManagerPageObject logInBankManager;
        private readonly AddCustomerButtonPageObject addCustomerButtonPage;

        private readonly ScenarioContext _scenarioContext;
        private User user;

        public AddCustomerStepDefinitions(BrowserDriver browserDriver, ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
            addCustomerPage = new AddCustomerPageObjects(browserDriver.Current);
            logInBankManager = new LogInBankManagerPageObject(browserDriver.Current);
            addCustomerButtonPage = new AddCustomerButtonPageObject(browserDriver.Current);
        }
        [Given("Customer with details:(.*),(.*),(.*)")]
        public void GivenCustomerWithDetailsFirstNameLastNamePostCode(string firstname, string lastname, string postcode)
        {
            user = new User(firstname, lastname, postcode);
        }


        [When("I log in as a \"Bank Manager\"")]
        public void WhenILogInAsA()
        {
            logInBankManager.LogInAsBankManager();
        }

        [When("I navigate to \"Add Customer\" page")]
        public void WhenINavigateToPage()
        {
            addCustomerButtonPage.NavigateToAddCustomerPage();
        }
        [When("fill the data")]
        public void WhenFillTheData()
        {
            addCustomerPage.FillCustomerDetails(user);
        }

        [When("I submit the form")]
        public void WhenISubmitTheForm()
        {
            addCustomerPage.SubmitCustomerForm();

        }

        [Then("customer id should be (.*)")]
        public void ThenCustomerIdShouldBe(string id)
        {
            var expectedResult = id;

            var actualResult = addCustomerPage.CustomerAddedSuccessfully();

            Assert.AreEqual(expectedResult, actualResult);
        }

        [Then(@"I should not see a message indicating that client added succesfully")]
        public void ThenIShouldNotSeeMessageIndicatingThatClientAddedSuccesfully()
        {
            var expectedResult = false;

            var actualResult = addCustomerPage.CustomerNotAddedSuccessfully();

            Assert.AreEqual(expectedResult, actualResult);
        }



    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2.Models
{
    public class User
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PostCode { get; set; }

        public User(string firstname,string lastname,string postcode) 
        { 
            FirstName = firstname;      
            LastName = lastname;
            PostCode = postcode;
        }
    }
}

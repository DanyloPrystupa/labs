﻿using Lab2.Models;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2.PageObjects
{
    internal class LogInBankManagerPageObject
    {
        private readonly IWebDriver _webDriver;

        private readonly string _loginBankManagerButtonXPath = "/html/body/div/div/div[2]/div/div[1]/div[2]/button";

        public LogInBankManagerPageObject(IWebDriver webDriver)
        {
            _webDriver = webDriver;
        }
        private IWebElement LoginBankManagerButton =>
           _webDriver.FindElement(By.XPath(_loginBankManagerButtonXPath));
        public void LogInAsBankManager()
        {
            LoginBankManagerButton.Click();
            Thread.Sleep(500);
        }
    }
}

﻿using Lab2.Models;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2.PageObjects
{
    internal class AddCustomerPageObjects
    {
        
            private readonly IWebDriver _webDriver;

           // private readonly string _loginBankManagerButtonXPath = "/html/body/div/div/div[2]/div/div[1]/div[2]/button";
            private readonly string _firstNameFieldXPath = "/html/body/div/div/div[2]/div/div[2]/div/div/form/div[1]/input";
            private readonly string _lastNameFieldXPath = "/html/body/div/div/div[2]/div/div[2]/div/div/form/div[2]/input";
            private readonly string _postCodeFieldXPath = "/html/body/div/div/div[2]/div/div[2]/div/div/form/div[3]/input";
            //private readonly string _addCustomerButtonPageXPath = "/html/body/div/div/div[2]/div/div[1]/button[1]";
            private readonly string _addCustomerButtonXPath = "/html/body/div/div/div[2]/div/div[2]/div/div/form/button";

            public AddCustomerPageObjects(IWebDriver webDriver)
            {
                _webDriver = webDriver;
            }
            /* private IWebElement LoginBankManagerButton=>
                _webDriver.FindElement(By.XPath(_loginBankManagerButtonXPath));*/
            private IWebElement FirstNameField =>
                _webDriver.FindElement(By.XPath(_firstNameFieldXPath));

            private IWebElement LastNameField =>
                _webDriver.FindElement(By.XPath(_lastNameFieldXPath));

            private IWebElement PostCodeField =>
                _webDriver.FindElement(By.XPath(_postCodeFieldXPath));

            /*private IWebElement AddCustomerButtonPage =>
              _webDriver.FindElement(By.XPath(_addCustomerButtonPageXPath));*/

            private IWebElement AddCustomerButton =>
                _webDriver.FindElement(By.XPath(_addCustomerButtonXPath));
            

            /*public void NavigateToAddCustomerPage()
            {
                AddCustomerButtonPage.Click();
                Thread.Sleep(500);
            }*/

            public void FillCustomerDetails(User user)
            {
                Thread.Sleep(500);
                FirstNameField.Clear();
                FirstNameField.SendKeys(user.FirstName);

                LastNameField.Clear();
                LastNameField.SendKeys(user.LastName);

                PostCodeField.Clear();
                PostCodeField.SendKeys(user.PostCode);
                

            }

            public void SubmitCustomerForm()
            {
                AddCustomerButton.Click();
                Thread.Sleep(500);
            }
            public string CustomerAddedSuccessfully()
            {

                IAlert simpleAlert = _webDriver.SwitchTo().Alert();


                String alertText = simpleAlert.Text;

                Thread.Sleep(500);

                return alertText.Split(':')[1];
            
            }
            public bool CustomerNotAddedSuccessfully()
            {
            try
            {
                IAlert alert = _webDriver.SwitchTo().Alert();
                
                string alertText = alert.Text;

                return true; 
            }
            catch (NoAlertPresentException)
            {
                Console.WriteLine("No alert found.");
               
            }
            return false;
        }

    }
}

﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2.PageObjects
{
    internal class AddCustomerButtonPageObject
    {
        private readonly IWebDriver _webDriver;

        private readonly string _addCustomerButtonPageXPath = "/html/body/div/div/div[2]/div/div[1]/button[1]";

        public AddCustomerButtonPageObject(IWebDriver webDriver)
        {
            _webDriver = webDriver;
        }
        private IWebElement AddCustomerButtonPage =>
             _webDriver.FindElement(By.XPath(_addCustomerButtonPageXPath));

        public void NavigateToAddCustomerPage()
        {
            AddCustomerButtonPage.Click();
            Thread.Sleep(500);
        }

    }
}
